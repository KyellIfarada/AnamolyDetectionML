#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  2 20:03:38 2024

@author: lorenzo
"""

import pandas as pd 

a = pd.read_csv("NSL-KDD/KDDTrain+_standardized.txt")
b = pd.read_csv("Testing-a1.csv")
c = pd.read_csv("Testing-a2-a4.csv")
d = pd.read_csv("Training-a1-a2.csv")
e = pd.read_csv("Training-a1-a3.csv")


print(a)

print(e)